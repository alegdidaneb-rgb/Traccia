# Traccia — pubblicazione su Vercel

Questa cartella contiene **il sito già compilato**, pronto da pubblicare.
`index.html` è in radice, gli asset sono in `assets/`, e `vercel.json` imposta
URL puliti, header di sicurezza e cache lunga per CSS/JS.

## Cosa c'è dentro

- 15 pagine HTML (home, come funziona, casi, cripto, chi siamo, onorari,
  supporto, login, area riservata, console analisti, 404, e le quattro legali)
- `assets/css/style.css` e 9 file JS
- `robots.txt`, `sitemap.xml`, `404.html`
- `vercel.json` con `cleanUrls: true` (quindi `/casi` funziona, oltre a `/casi.html`)

Peso totale: ~490 KB. Nessuna build, nessuna dipendenza: Vercel serve i file così
come sono.

---

## Opzione A — drag & drop (2 minuti, nessun comando)

1. Vai su <https://vercel.com/new>
2. Trascina **questa cartella** nella zona di caricamento
3. Nome progetto: `traccia`
4. Framework preset: **Other** (non c'è nulla da compilare)
5. Deploy

## Opzione B — da terminale

```bash
cd traccia-deploy
npx vercel          # anteprima
npx vercel --prod   # produzione
```

Alla prima esecuzione risponde a poche domande: framework `Other`,
build command vuoto, output directory `.` (la radice).

## Opzione C — GitHub + deploy automatico

```bash
cd traccia-deploy
git init && git add -A
git commit -m "Traccia — sito di analisi forense"
git branch -M main
git remote add origin git@github.com:<tuo-utente>/traccia.git
git push -u origin main
```

Poi su Vercel: **Add New → Project → Import Git Repository → traccia → Deploy**.
Da quel momento ogni push su `main` ripubblica il sito.

---

## Dopo il deploy

### 1. Imposta il dominio reale

Nel progetto Vercel → **Settings → Domains** → aggiungi `traccia.it`.
Poi, nel pannello del registrar:

| Tipo | Nome | Valore |
|---|---|---|
| A | `@` | `76.76.21.21` |
| CNAME | `www` | `cname.vercel-dns.com` |

Verifica con `dig traccia.it` dopo qualche ora.

### 2. Aggiorna il config e ricompila

Tutti gli URL assoluti (sitemap, `robots.txt`, meta tag) vengono da
`site.config.json`. Quando il dominio è definitivo:

```bash
# nella cartella di lavoro
python3 build.py     # rigenera public/
```

poi ricarica i file nuovi.

### 3. Form e area riservata

Il sito è **statico**: il modulo contatti e il login funzionano in modalità
demo (i dati restano nel browser, compare una barra gialla). Per avere login
reale, pratiche e console analisti servono il backend Python in `backend/`,
che Vercel non esegue così com'è: va portato su un host che supporti Python
(Render, Railway, Fly.io) e poi puntato dal client con una variabile d'ambiente.

---

## Attenzione prima di andare online per davvero

I numeri e i contenuti dei casi sono **dimostrativi**: 38,4 Mln €, 9,7 Mln €
rientrati, 612 perizie, i quattro casi con i loro importi, i nomi e le
biografie delle nove persone del team, gli indirizzi email su `traccia.it`.

Sono affermazioni verificabili. Vanno sostituite con dati reali prima della
pubblicazione, altrimenti il sito dichiara cose non vere — ed è esattamente il
tipo di contenuto per cui un servizio di questo settore perde ogni credibilità.

Punti da rivedere, in ordine di rischio:

1. **Team** (`chi-siamo.html` e sezione team in home): nomi, ruoli, biografie
2. **Risultati** (`casi.html`, banda numerica in home): importi e conteggi
3. **Dati societari** nel footer: attualmente ERSEL SPA con Albo Banche n. 5573
   e vigilanza Banca d'Italia e CONSOB — da confermare per questa attività
4. **Recapiti**: `ciao@traccia.it`, `assistenza@traccia.it`, PEC, telefono
5. **Onorari**: 190 € + 12% — da allineare al contratto reale
