/* traccia — API client (versione semplice: sessione, niente fallback). */
(function (global) {
  "use strict";

  var TOKEN_KEY = "traccia.session";
  var memory = {};   // fallback se localStorage è bloccato

  function store(operation, key, value) {
    try {
      if (operation === "get") return window.localStorage.getItem(key) || "";
      if (operation === "set") return window.localStorage.setItem(key, value);
      return window.localStorage.removeItem(key);
    } catch (e) {
      if (operation === "get") return memory[key] || "";
      if (operation === "set") memory[key] = value;
      else delete memory[key];
    }
  }

  function token() { return store("get", TOKEN_KEY); }
  function setToken(value) {
    if (value) store("set", TOKEN_KEY, value);
    else store("del", TOKEN_KEY);
  }


  /* ------------------------------------------------------------------------
     MODO DEMO (solo anteprima statica).
     Se il sito è aperto senza backend — file viewer, hosting statico — le
     chiamate /api non esistono e il server risponde 501/405/404. In quel caso
     usiamo un dataset locale identico a quello del backend, così la demo resta
     navigabile. Se il backend risponde, questo codice non viene mai eseguito.
     ------------------------------------------------------------------------ */
  var DEMO_KEY = "traccia.demo";

  var DEMO_USERS = [
    { email: "master@traccia.it", password: "Master!2026", name: "Master Control",
      role: "admin", is_master: true, status: "active", kyc_level: 3, balance_eur: 0 },
    { email: "ops@traccia.it", password: "Ops!2026", name: "Sara Conti",
      role: "admin", is_master: false, status: "active", kyc_level: 2, balance_eur: 0 },
    { email: "luca.bianchi@example.it", password: "Demo!2026", name: "Luca Bianchi",
      role: "user", is_master: false, status: "active", kyc_level: 2, balance_eur: 2268.90 },
    { email: "giulia.rossi@example.it", password: "Demo!2026", name: "Giulia Rossi",
      role: "user", is_master: false, status: "pending", kyc_level: 1, balance_eur: 0 },
    { email: "marco.verdi@example.it", password: "Demo!2026", name: "Marco Verdi",
      role: "user", is_master: false, status: "pending", kyc_level: 1, balance_eur: 0 },
    { email: "elena.ferrari@example.it", password: "Demo!2026", name: "Elena Ferrari",
      role: "user", is_master: false, status: "suspended", kyc_level: 1, balance_eur: 120 }
  ];

  var DEMO_MARKET = [
    ["BTC","Bitcoin",61240.50,1.84,"#f7931a"], ["ETH","Ethereum",2847.30,2.42,"#627eea"],
    ["SOL","Solana",148.72,-1.16,"#14f195"],   ["XRP","XRP",0.5248,0.64,"#23292f"],
    ["ADA","Cardano",0.3821,-0.42,"#0033ad"],  ["DOT","Polkadot",4.18,1.05,"#e6007a"],
    ["LINK","Chainlink",11.06,3.12,"#2a5ada"], ["MATIC","Polygon",0.4132,-2.08,"#8247e5"],
    ["AVAX","Avalanche",24.35,0.88,"#e84142"], ["DOGE","Dogecoin",0.1342,4.26,"#c2a633"]
  ].map(function (a) {
    return { symbol: a[0], name: a[1], price_eur: a[2], change_24h: a[3], color: a[4],
             category: "Cripto", tradable_247: true };
  });

  var _demoCache = null;

  function demoSeedUsers() {
    return DEMO_USERS.map(function (u) { return Object.assign({}, u); });
  }

  /* Lista utenti della demo: parte dal seed e viene salvata in localStorage,
     così gli account creati dall'amministratore sopravvivono al reload. */
  function demoUsers() { return demoLoad().users; }

  /* --- IBAN italiani: stessa logica del backend (CIN + checksum modulo 97) -- */
  var IBAN_BANKS = [
    ["01005", "Banca Nazionale del Lavoro"], ["02008", "UniCredit"],
    ["03069", "Intesa Sanpaolo"], ["03032", "Banca Sella"],
    ["05034", "Banco BPM"], ["03104", "Banca Mediolanum"],
    ["03669", "FinecoBank"], ["07601", "Poste Italiane (BancoPosta)"],
    ["08327", "Banca Popolare di Sondrio"], ["03475", "Banca Generali"]
  ];
  var CIN_ODD = {
    "0": 1, "1": 0, "2": 5, "3": 7, "4": 9, "5": 13, "6": 15, "7": 17, "8": 19,
    "9": 21, "A": 1, "B": 0, "C": 5, "D": 7, "E": 9, "F": 13, "G": 15, "H": 17,
    "I": 19, "J": 21, "K": 2, "L": 4, "M": 18, "N": 20, "O": 11, "P": 3, "Q": 6,
    "R": 8, "S": 12, "T": 14, "U": 16, "V": 10, "W": 22, "X": 25, "Y": 24, "Z": 23
  };

  function mod97(value) {
    var rest = 0;
    for (var i = 0; i < value.length; i++) rest = (rest * 10 + Number(value[i])) % 97;
    return rest;
  }

  function bankName(iban) {
    var abi = iban.slice(5, 10);
    for (var i = 0; i < IBAN_BANKS.length; i++) if (IBAN_BANKS[i][0] === abi) return IBAN_BANKS[i][1];
    return "Banca convenzionata";
  }

  function formatIban(iban) {
    return (iban || "").replace(/(.{4})/g, "$1 ").trim();
  }

  function generateIban() {
    var bank = IBAN_BANKS[Math.floor(Math.random() * IBAN_BANKS.length)];
    var abi = bank[0];
    var digits = function (n) {
      var out = "";
      for (var i = 0; i < n; i++) out += String(Math.floor(Math.random() * 10));
      return out;
    };
    var cab = digits(5);
    var account = digits(12);
    var sequence = abi + cab + account;
    var total = 0;
    for (var i = 0; i < sequence.length; i++) {
      total += i % 2 === 0 ? CIN_ODD[sequence[i]]
                           : (isNaN(Number(sequence[i])) ? sequence.charCodeAt(i) - 55
                                                        : Number(sequence[i]));
    }
    var cin = String.fromCharCode(65 + (total % 26));
    var bban = cin + sequence;
    var numeric = (bban + "IT00").replace(/[A-Z]/g, function (ch) {
      return String(ch.charCodeAt(0) - 55);
    });
    var check = ("0" + (98 - mod97(numeric))).slice(-2);
    return "IT" + check + bban;
  }

  function demoLoad() {
    if (_demoCache) return _demoCache;
    var raw = store("get", DEMO_KEY);
    if (raw) { try { _demoCache = JSON.parse(raw); } catch (e) {} }
    if (_demoCache) {
      if (!_demoCache.users) _demoCache.users = demoSeedUsers();
      return _demoCache;
    }
    _demoCache = {
      session: null,
      users: demoSeedUsers().map(function (u) {
        return Object.assign({}, u, { iban: generateIban() });
      }),
      ops: [
        { id: 1, user_id: 3, type: "deposit", symbol: null, amount_eur: 500,
          status: "pending", created_at: Date.now()/1000 - 900 },
        { id: 2, user_id: 3, type: "buy", symbol: "BTC", amount_eur: 250,
          status: "denied", created_at: Date.now()/1000 - 3600,
          decision_note: "Documento non leggibile" }
      ],
      wallets: [],
      holdings: { "luca.bianchi@example.it": { BTC: 0.0142, ETH: 0.84 } },
      settings: {
        daily_deposit_l1: 1000, daily_deposit_l2: 10000, daily_deposit_l3: 0,
        daily_withdrawal_l1: 500, daily_withdrawal_l2: 5000, daily_withdrawal_l3: 0,
        daily_buy_l1: 1000, daily_buy_l2: 10000, daily_buy_l3: 0,
        daily_sell_l1: 1000, daily_sell_l2: 10000, daily_sell_l3: 0,
        crypto_transfer_max_eur_l1: 0, crypto_transfer_max_eur_l2: 2000,
        crypto_transfer_max_eur_l3: 0,
        crypto_transfer_enabled: 1, wallet_requires_approval: 1,
        wallet_requires_signature: 1
      }
    };
    return _demoCache;
  }

  function demoSave(state) {
    _demoCache = state;
    store("set", DEMO_KEY, JSON.stringify(state));
  }

  function demoUser(email) {
    var list = demoUsers();
    var found = list.filter(function (u) { return u.email === email; })[0];
    if (!found) return null;
    return { id: list.indexOf(found) + 1, email: found.email, name: found.name,
             role: found.role, is_master: found.is_master, status: found.status,
             kyc_level: found.kyc_level, balance_eur: found.balance_eur,
             iban: found.iban || null, iban_formatted: formatIban(found.iban),
             iban_bank: found.iban ? bankName(found.iban) : "",
             kyc_label: ["Base — documento d'identità",
                         "Avanzata — residenza e fonte dei fondi",
                         "Completa — verifica rafforzata"][found.kyc_level - 1] };
  }

  function demoPortfolio(user, state) {
    var held = state.holdings[user.email] || {};
    var holdings = Object.keys(held).map(function (symbol) {
      var asset = DEMO_MARKET.filter(function (a) { return a.symbol === symbol; })[0];
      var price = asset ? asset.price_eur : 0;
      return { symbol: symbol, quantity: held[symbol], price_eur: price,
               value_eur: Math.round(held[symbol] * price * 100) / 100,
               cost_basis: Math.round(held[symbol] * price * 0.9 * 100) / 100,
               pnl_eur: Math.round(held[symbol] * price * 0.1 * 100) / 100 };
    });
    var total = holdings.reduce(function (sum, h) { return sum + h.value_eur; }, 0);
    return { holdings: holdings, holdings_value_eur: Math.round(total * 100) / 100,
             balance_eur: user.balance_eur,
             net_worth_eur: Math.round((total + user.balance_eur) * 100) / 100 };
  }

  /* --- prezzi reali anche in anteprima statica ------------------------------
     CoinGecko consente le chiamate dal browser (CORS aperto). Se la rete non
     è disponibile restano i prezzi di riferimento di DEMO_MARKET. */
  var LIVE_KEY = "traccia.live";
  var LIVE_TTL = 8000;
  var CG_IDS = {
    BTC: "bitcoin", ETH: "ethereum", SOL: "solana", XRP: "ripple",
    ADA: "cardano", DOT: "polkadot", LINK: "chainlink", MATIC: "matic-network",
    AVAX: "avalanche-2", DOGE: "dogecoin"
  };
  var liveCache = { at: 0, assets: null, meta: null, pending: null };

  function demoLiveMarket() {
    var now = Date.now();
    if (liveCache.assets && now - liveCache.at < LIVE_TTL) {
      return Promise.resolve({ assets: liveCache.assets, market: liveCache.meta });
    }
    if (liveCache.pending) return liveCache.pending;

    var ids = Object.keys(CG_IDS).map(function (k) { return CG_IDS[k]; }).join(",");
    var url = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=eur&ids=" +
      ids + "&price_change_percentage=24h&sparkline=false";

    liveCache.pending = fetch(url, { headers: { Accept: "application/json" } })
      .then(function (res) { return res.ok ? res.json() : Promise.reject(res.status); })
      .then(function (list) {
        var byId = {};
        list.forEach(function (coin) {
          var symbol = null;
          Object.keys(CG_IDS).forEach(function (sym) {
            if (CG_IDS[sym] === coin.id) symbol = sym;
          });
          if (symbol) byId[symbol] = coin;
        });
        var assets = DEMO_MARKET.map(function (a) {
          var coin = byId[a.symbol];
          if (!coin) return a;
          return Object.assign({}, a, {
            price_eur: coin.current_price,
            change_24h: Math.round((coin.price_change_percentage_24h || 0) * 100) / 100,
            market_cap_eur: coin.market_cap || a.market_cap_eur,
            volume_24h_eur: coin.total_volume || a.volume_24h_eur,
            price_source: "coingecko"
          });
        });
        liveCache = {
          at: Date.now(), assets: assets, pending: null,
          meta: { source: "coingecko", fetched_at: Date.now() / 1000,
                  age_seconds: 0, stale: false, error: "" }
        };
        return { assets: assets, market: liveCache.meta };
      })
      .catch(function () {
        liveCache.pending = null;
        var stale = { source: "reference", fetched_at: null, age_seconds: null,
                      stale: true, error: "rete non disponibile" };
        return { assets: DEMO_MARKET, market: stale };
      });
    return liveCache.pending;
  }

  function demoLogin(email, password) {
    var found = demoUsers().filter(function (u) {
      return u.email === (email || "").trim().toLowerCase();
    })[0];
    if (!found || found.password !== password) {
      return Promise.reject(Object.assign(new Error("Email o password non corretti."),
                                          { status: 401, code: "bad_credentials" }));
    }
    if (found.status === "pending") {
      return Promise.reject(Object.assign(
        new Error("Il tuo account è in attesa di approvazione da parte dell'amministratore."),
        { status: 403, code: "account_pending" }));
    }
    if (found.status === "suspended") {
      return Promise.reject(Object.assign(new Error("Account sospeso. Contatta l'assistenza."),
                                          { status: 403, code: "account_suspended" }));
    }
    var token = "demo." + btoa(found.email).replace(/=/g, "");
    var state = demoLoad(); state.session = found.email; demoSave(state);
    setToken(token);
    return Promise.resolve({ token: token, user: demoUser(found.email) });
  }

  function demoRequest(method, path, body) {
    var state = demoLoad();
    var email = state.session;
    var user = email ? demoUser(email) : null;
    var clean = path.split("?")[0];
    var users = demoUsers();
    var need = function () {
      if (!user) throw Object.assign(new Error("Sessione non valida."),
                                    { status: 401, code: "unauthorised" });
      return user;
    };

    body = body || {};
    if (clean === "/api/auth/login") return demoLogin(body.email, body.password);
    if (clean === "/api/auth/logout") {
      state.session = null; demoSave(state); setToken(""); return Promise.resolve({ ok: true });
    }
    if (clean === "/api/auth/me") {
      var me = need();
      return Promise.resolve({ user: me, portfolio: demoPortfolio(me, state) });
    }
    if (clean === "/api/crypto") {
      return demoLiveMarket().then(function (data) {
        return { assets: data.assets, market: data.market, tradable: true,
                 note: data.market.stale
                   ? "Prezzi di riferimento: rete non disponibile"
                   : "Prezzi di mercato in tempo reale (fonte: CoinGecko)" };
      });
    }
    if (clean === "/api/me/portfolio") return Promise.resolve(demoPortfolio(need(), state));
    if (clean === "/api/me/limits") {
      var u = need();
      var limit = function (type) {
        var cap = state.settings["daily_" + type + "_l" + u.kyc_level] || 0;
        return { daily_cap_eur: cap, used_24h_eur: 0,
                 remaining_eur: cap ? cap : null };
      };
      return Promise.resolve({
        kyc_level: u.kyc_level, kyc_label: u.kyc_label,
        limits: { deposit: limit("deposit"), withdrawal: limit("withdrawal"),
                  buy: limit("buy"), sell: limit("sell") },
        crypto_transfer: { enabled: !!state.settings.crypto_transfer_enabled,
                           max_eur: state.settings["crypto_transfer_max_eur_l" + u.kyc_level] || 0,
                           allowed: true },
        networks: { BTC: ["Bitcoin"], ETH: ["Ethereum", "Arbitrum", "Base"],
                    SOL: ["Solana"], XRP: ["XRP Ledger"], ADA: ["Cardano"],
                    DOT: ["Polkadot"], LINK: ["Ethereum", "Arbitrum"],
                    MATIC: ["Polygon"], AVAX: ["Avalanche C-Chain"], DOGE: ["Dogecoin"] }
      });
    }
    if (clean === "/api/me/operations" && method === "GET") {
      var cu = need();
      var status = /status=([a-z]+)/.exec(path);
      var list = state.ops.filter(function (o) {
        return o.user_id === cu.id && (!status || o.status === status[1]);
      });
      return Promise.resolve({ operations: list });
    }
    if (clean === "/api/me/operations" && method === "POST") {
      var ou = need();
      var op = { id: state.ops.length + 1, user_id: ou.id, type: body.type,
                 symbol: body.symbol || null,
                 amount_eur: body.type === "transfer_out"
                   ? Math.round((body.quantity || 0) *
                       (DEMO_MARKET.filter(function (a) { return a.symbol === body.symbol; })[0] || {}
                       ).price_eur * 100) / 100
                   : Number(body.amount_eur) || 0,
                 quantity: body.quantity || null, wallet_address: body.address || null,
                 status: "pending", created_at: Date.now() / 1000 };
      state.ops.unshift(op); demoSave(state);
      return Promise.resolve({ ok: true, id: op.id, status: "pending",
        message: "Richiesta inviata. In attesa di approvazione." });
    }
    if (/^\/api\/me\/operations\/\d+\/cancel$/.test(clean)) {
      var id = parseInt(clean.split("/")[4], 10);
      state.ops.forEach(function (o) { if (o.id === id) o.status = "cancelled"; });
      demoSave(state); return Promise.resolve({ ok: true });
    }
    if (clean === "/api/me/wallets" && method === "GET") {
      var wu = need();
      return Promise.resolve({
        wallets: state.wallets.filter(function (w) { return w.user_id === wu.id; }),
        networks: { BTC: ["Bitcoin"], ETH: ["Ethereum", "Arbitrum", "Base"],
                    SOL: ["Solana"], XRP: ["XRP Ledger"], ADA: ["Cardano"],
                    DOT: ["Polkadot"], LINK: ["Ethereum", "Arbitrum"],
                    MATIC: ["Polygon"], AVAX: ["Avalanche C-Chain"], DOGE: ["Dogecoin"] },
        requires_approval: true,
        requires_signature: !!state.settings.wallet_requires_signature
      });
    }
    if (clean === "/api/me/wallets" && method === "POST") {
      var au = need();
      var exists = state.wallets.filter(function (w) {
        return w.user_id === au.id && w.address === body.address;
      })[0];
      if (!exists) {
        exists = { id: state.wallets.length + 1, user_id: au.id, user_name: au.name,
                   user_email: au.email, symbol: body.symbol, address: body.address,
                   network: body.network, status: "pending",
                   created_at: Date.now() / 1000, challenge_done_at: null };
        state.wallets.unshift(exists); demoSave(state);
      }
      return Promise.resolve({ ok: true, status: exists.status, wallet: exists,
        message: "Indirizzo aggiunto: in attesa di approvazione." });
    }
    if (/challenge$/.test(clean)) {
      var wid = parseInt(clean.split("/")[4], 10);
      return Promise.resolve({
        id: 1, wallet_id: wid,
        message: "traccia wallet verification\nNonce: demo-" + wid + "\n" +
                 "Firmando questo messaggio confermi la proprietà dell'indirizzo.",
        expires_at: Date.now() / 1000 + 86400,
        instructions: "Firma il messaggio con il wallet e incolla la firma."
      });
    }
    if (/signature$/.test(clean)) {
      var sid = parseInt(clean.split("/")[4], 10);
      state.wallets.forEach(function (w) {
        if (w.id === sid) { w.challenge_done_at = Date.now() / 1000;
                            w.signature = body.signature; }
      });
      demoSave(state);
      return Promise.resolve({ ok: true, wallet_id: sid, status: "pending",
        message: "Firma acquisita. In attesa della verifica finale." });
    }

    /* ---- area amministratore ---- */
    if (clean === "/api/admin/overview") {
      var all = state.ops;
      var accs = users;
      return Promise.resolve({
        pending_accounts: accs.filter(function (u) { return u.status === "pending"; }).length,
        pending_operations: all.filter(function (o) { return o.status === "pending"; }).length,
        pending_wallets: state.wallets.filter(function (w) { return w.status === "pending"; }).length,
        active_users: accs.filter(function (u) { return u.status === "active"; }).length,
        total_balance_eur: accs.reduce(function (s, u) { return s + u.balance_eur; }, 0),
        by_type: {}, audit: []
      });
    }
    if (clean === "/api/admin/accounts" && method === "POST") {
      var actor = need();
      if (actor.role !== "admin") {
        return Promise.reject(Object.assign(new Error("Area riservata agli amministratori."),
                                            { status: 403, code: "forbidden" }));
      }
      var mail = (body.email || "").trim().toLowerCase();
      if (!mail || mail.indexOf("@") === -1) {
        return Promise.reject(Object.assign(new Error("Inserisci un indirizzo email valido."),
                                            { status: 400, code: "invalid_email" }));
      }
      if (!(body.name || "").trim()) {
        return Promise.reject(Object.assign(new Error("Inserisci nome e cognome del cliente."),
                                            { status: 400, code: "missing_name" }));
      }
      if (users.some(function (u) { return u.email === mail; })) {
        return Promise.reject(Object.assign(new Error("Esiste già un account con questa email."),
                                            { status: 409, code: "email_taken" }));
      }
      var pwd = (body.password || "").trim();
      var generated = false;
      if (!pwd) {
        pwd = "traccia-" + Math.random().toString(36).slice(2, 10);
        generated = true;
      } else if (pwd.length < 8) {
        return Promise.reject(Object.assign(new Error("La password deve avere almeno 8 caratteri."),
                                            { status: 400, code: "weak_password" }));
      }
      if (body.role === "admin" && !actor.is_master) {
        return Promise.reject(Object.assign(
          new Error("Solo l'account master può creare amministratori."),
          { status: 403, code: "master_only" }));
      }
      var created = {
        email: mail, password: pwd, name: (body.name || "").trim(),
        role: body.role === "admin" ? "admin" : "user", is_master: false,
        status: body.status === "pending" ? "pending" : "active",
        kyc_level: Number(body.kyc_level) || 1,
        balance_eur: Number(body.balance_eur) || 0,
        iban: generateIban()
      };
      users.push(created);
      var holder = {};
      holder[mail] = {};
      state.holdings = state.holdings || {};
      Object.keys(holder).forEach(function (k) { state.holdings[k] = {}; });
      demoSave(state);
      return Promise.resolve({
        ok: true, user: demoUser(mail),
        credentials: { email: mail, password: pwd, generated: generated,
                       iban: created.iban }
      });
    }
    if (clean === "/api/admin/accounts") {
      var filter = /status=([a-z]+)/.exec(path);
      return Promise.resolve({ accounts: users.map(function (u) {
        return Object.assign(demoUser(u.email), {
          created_at: Date.now() / 1000, operations_count: 0, holdings_value: 0,
          kyc_level: u.kyc_level
        });
      }).filter(function (u) { return !filter || u.status === filter[1]; }) });
    }
    if (/^\/api\/admin\/accounts\/\d+\/(approve|deny|suspend|reactivate)$/.test(clean)) {
      var parts = clean.split("/");
      var uid = parseInt(parts[4], 10);
      var action = parts[5];
      var next = { approve: "active", reactivate: "active", deny: "denied",
                   suspend: "suspended" }[action];
      var target = users[uid - 1];
      if (target && target.is_master) {
        return Promise.reject(Object.assign(
          new Error("L'account master non può essere modificato."),
          { status: 409, code: "master_protected" }));
      }
      if (target) { target.status = next; demoSave(state); }
      return Promise.resolve({ ok: true, id: uid, status: next });
    }
    if (/^\/api\/admin\/accounts\/\d+\/kyc$/.test(clean)) {
      var kid = parseInt(clean.split("/")[4], 10);
      if (users[kid - 1]) { users[kid - 1].kyc_level = body.kyc_level; demoSave(state); }
      return Promise.resolve({ ok: true, id: kid, kyc_level: body.kyc_level });
    }
    if (clean === "/api/admin/operations") {
      var of = /status=([a-z]+)/.exec(path);
      return Promise.resolve({ operations: state.ops
        .filter(function (o) { return !of || o.status === of[1]; })
        .map(function (o) {
          var owner = users[o.user_id - 1] || {};
          return Object.assign({}, o, { user_email: owner.email, user_name: owner.name });
        }) });
    }
    if (/^\/api\/admin\/operations\/\d+\/(approve|deny)$/.test(clean)) {
      var oparts = clean.split("/");
      var oid = parseInt(oparts[4], 10);
      var oaction = oparts[5];
      state.ops.forEach(function (o) {
        if (o.id === oid) { o.status = oaction === "approve" ? "approved" : "denied";
                            o.decision_note = body.note || ""; }
      });
      demoSave(state);
      return Promise.resolve({ ok: true, id: oid, status: oaction === "approve" ? "approved" : "denied" });
    }
    if (clean === "/api/admin/wallets") {
      var wf = /status=([a-z]+)/.exec(path);
      return Promise.resolve({ wallets: state.wallets
        .filter(function (w) { return !wf || w.status === wf[1]; }) });
    }
    if (/^\/api\/admin\/wallets\/\d+\/(approve|deny)$/.test(clean)) {
      var wp = clean.split("/");
      var wid2 = parseInt(wp[4], 10);
      var wact = wp[5];
      state.wallets.forEach(function (w) {
        if (w.id === wid2) w.status = wact === "approve" ? "approved" : "denied";
      });
      demoSave(state);
      return Promise.resolve({ ok: true, id: wid2,
                               status: wact === "approve" ? "approved" : "denied" });
    }
    if (clean === "/api/admin/settings") {
      if (method === "GET") {
        return Promise.resolve({ settings: state.settings, defaults: state.settings,
                                 kyc_labels: {}, networks: {} });
      }
      Object.keys(body.settings || {}).forEach(function (k) {
        state.settings[k] = body.settings[k];
      });
      demoSave(state);
      return Promise.resolve({ settings: state.settings });
    }

    return Promise.reject(Object.assign(new Error("Funzione non disponibile in demo."),
                                        { status: 404, code: "no_demo_route" }));
  }

  /* true quando le chiamate devono passare dal dataset locale */
  var demoMode = false;
  var modePromise = null;
  function isDemo() { return demoMode; }

  /* ogni chiamata passa da qui: prima si decide backend o demo, una volta sola */
  function request(method, path, body) {
    if (modePromise === null) modePromise = detectMode();
    return modePromise.then(function (offline) {
      if (offline) return demoRequest(method, path, body);
      return realRequest(method, path, body);
    });
  }

  function detectMode() {
    /* una sola sonda: se /api/health non risponde correttamente, siamo offline */
    return fetch("/api/health", { method: "GET", credentials: "same-origin",
                                  headers: { Accept: "application/json" } })
      .then(function (res) { return res.ok ? res.json() : null; })
      .then(function (data) {
        demoMode = !(data && data.service === "traccia");
        return demoMode;
      })
      .catch(function () { demoMode = true; return true; });
  }

  function realRequest(method, path, body) {
    var headers = { Accept: "application/json" };
    var current = token();
    if (current) headers.Authorization = "Bearer " + current;
    if (body !== undefined) headers["Content-Type"] = "application/json";

    return fetch(path, {
      method: method,
      headers: headers,
      credentials: "same-origin",
      body: body === undefined ? undefined : JSON.stringify(body)
    }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) {
        if (!res.ok) {
          var err = new Error(data.error || "Errore del server (" + res.status + ")");
          err.status = res.status;
          err.code = data.code;
          throw err;
        }
        return data;
      });
    });
  }

  var api = {
    detectMode: detectMode,
    isDemo: isDemo,
    token: token,
    setToken: setToken,
    get: function (p) { return request("GET", p); },
    post: function (p, b) { return request("POST", p, b === undefined ? {} : b); },
    patch: function (p, b) { return request("PATCH", p, b === undefined ? {} : b); },

    /* auth */
    login: function (email, password) {
      return request("POST", "/api/auth/login", { email: email, password: password })
        .then(function (data) { setToken(data.token); return data; });
    },
    register: function (payload) { return request("POST", "/api/auth/register", payload); },
    logout: function () {
      return request("POST", "/api/auth/logout", {})
        .catch(function () {})
        .then(function () { setToken(""); });
    },
    me: function () { return request("GET", "/api/auth/me"); },

    /* cliente */
    limits: function () { return request("GET", "/api/me/limits"); },
    portfolio: function () { return request("GET", "/api/me/portfolio"); },
    crypto: function () { return request("GET", "/api/crypto"); },
    myOperations: function (status) {
      return request("GET", "/api/me/operations" + (status ? "?status=" + status : ""));
    },
    createOperation: function (payload) { return request("POST", "/api/me/operations", payload); },
    cancelOperation: function (id) {
      return request("POST", "/api/me/operations/" + id + "/cancel", {});
    },
    myWallets: function () { return request("GET", "/api/me/wallets"); },
    addWallet: function (payload) { return request("POST", "/api/me/wallets", payload); },
    walletChallenge: function (id) {
      return request("POST", "/api/me/wallets/" + id + "/challenge", {});
    },
    walletSignature: function (id, signature) {
      return request("POST", "/api/me/wallets/" + id + "/signature", { signature: signature });
    },

    /* amministrazione */
    overview: function () { return request("GET", "/api/admin/overview"); },
    createAccount: function (payload) {
      return request("POST", "/api/admin/accounts", payload);
    },
    accounts: function (status) {
      return request("GET", "/api/admin/accounts" + (status ? "?status=" + status : ""));
    },
    accountAction: function (id, action, note) {
      return request("POST", "/api/admin/accounts/" + id + "/" + action, { note: note || "" });
    },
    setRole: function (id, role) {
      return request("PATCH", "/api/admin/accounts/" + id + "/role", { role: role });
    },
    setKyc: function (id, level, note) {
      return request("PATCH", "/api/admin/accounts/" + id + "/kyc",
                     { kyc_level: level, note: note || "" });
    },
    operations: function (status) {
      return request("GET", "/api/admin/operations" + (status ? "?status=" + status : ""));
    },
    operationAction: function (id, action, note) {
      return request("POST", "/api/admin/operations/" + id + "/" + action, { note: note || "" });
    },
    adminWallets: function (status) {
      return request("GET", "/api/admin/wallets" + (status ? "?status=" + status : ""));
    },
    walletAction: function (id, action, note) {
      return request("POST", "/api/admin/wallets/" + id + "/" + action, { note: note || "" });
    },
    settings: function () { return request("GET", "/api/admin/settings"); },
    saveSettings: function (settings) {
      return request("PATCH", "/api/admin/settings", { settings: settings });
    }
  };

  global.api = api;
})(window);
