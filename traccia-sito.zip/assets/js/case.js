/* traccia — vista "La mia pratica": riempie i dati del fascicolo.
   I dati sono dimostrativi e restano nel browser: nessun dato lascia
   il dispositivo in modalità demo. */
(function () {
  "use strict";

  var PHASES = [
    "01 · Raccolta",
    "02 · Ricostruzione",
    "03 · Perizia",
    "04 · Denunce",
    "05 · Legale"
  ];

  function set(name, value) {
    document.querySelectorAll("[data-" + name + "]").forEach(function (node) {
      node.textContent = value;
    });
  }

  function initials(name) {
    return (name || "")
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map(function (w) { return w[0].toUpperCase(); })
      .join("");
  }

  function readUser() {
    // api.js salva l'utente corrente; in demo c'è un fallback locale
    try {
      var raw = window.localStorage.getItem("traccia.session.user");
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return null;
  }

  function caseRef() {
    var ref = null;
    try { ref = window.localStorage.getItem("traccia.case_ref"); } catch (e) {}
    if (!ref) {
      ref = "T-" + String(Math.floor(1000 + Math.random() * 8999)) + "-2026";
      try { window.localStorage.setItem("traccia.case_ref", ref); } catch (e) {}
    }
    return ref;
  }

  function boot() {
    var user = readUser();
    var ref = caseRef();
    set("case-ref", ref);
    var name = (user && (user.name || user.full_name)) || "";
    if (name) {
      set("user-name", name);
      set("user-first", name.split(/\s+/)[0]);
      set("user-initials", initials(name));
    }
    if (user && user.email) set("user-email", user.email);

    // dati del fascicolo (dimostrativi)
    var currentPhase = 3;                       // indice 1-based
    set("stat-phase", PHASES[currentPhase - 1]);
    set("stat-updated", "30 ott 2026");
    set("stat-amount", "38.400,00 €");
    set("stat-docs", "2 / 4");
    set("docs-count", "2");
    set("user-status-line", "Pratica " + ref + " · Fase 03 — Perizia in redazione");

    // pulsante di copia del riferimento
    var copy = document.querySelector("[data-copy-ref]");
    if (copy) {
      copy.addEventListener("click", function () {
        if (navigator.clipboard) navigator.clipboard.writeText(ref);
        copy.textContent = "Copiato";
        window.setTimeout(function () { copy.textContent = "Copia"; }, 1600);
      });
    }

    // evidenzia la fase corrente nel tracciato
    var steps = document.querySelectorAll("[data-phase-track] .phase-track__step");
    steps.forEach(function (step, i) {
      step.classList.remove("is-done", "is-current");
      if (i + 1 < currentPhase) step.classList.add("is-done");
      else if (i + 1 === currentPhase) step.classList.add("is-current");
    });

    // il form del caricamento documento è simulato
    var form = document.querySelector("#op-form");
    if (form) {
      form.addEventListener("submit", function (ev) {
        ev.preventDefault();
        var note = form.querySelector("[data-form-error]");
        if (note) {
          note.hidden = false;
          note.textContent =
            "Documento registrato nella pratica (simulazione: nessun file è stato inviato).";
        }
        var count = document.querySelector("[data-docs-count]");
        if (count) count.textContent = String(Number(count.textContent || 0) + 1);
        form.reset();
      });
    }

    // le tab della barra laterale
    document.querySelectorAll(".app-side [data-tab]").forEach(function (link) {
      link.addEventListener("click", function () {
        document.querySelectorAll(".app-side [data-tab]").forEach(function (l) {
          l.classList.remove("is-active");
        });
        link.classList.add("is-active");
      });
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
