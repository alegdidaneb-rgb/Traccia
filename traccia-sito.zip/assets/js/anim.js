/* traccia — motore di animazione all'ingresso nel viewport.
   Sostituisce il vecchio "reveal + failsafe": l'animazione parte quando
   l'elemento entra davvero in vista, con stagger tra elementi fratelli.
   Se il JS non parte, il contenuto resta visibile (vedi CSS: la classe
   .js-anim sul <html> è l'unica cosa che nasconde qualcosa). */
(function () {
  "use strict";

  var STAGGER = 90;        // ms tra un elemento e il successivo dello stesso gruppo
  var MAX_STAGGER = 540;   // tetto, per non trasformare una griglia in una fila
  var ONCE = true;

  var root = document.documentElement;

  /* ---------------------------------------------------------- utils -- */
  function reduced() {
    var query = window.matchMedia("(prefers-reduced-motion: reduce)");
    return query.matches;
  }

  function inViewport(el) {
    var r = el.getBoundingClientRect();
    return r.top < window.innerHeight && r.bottom > 0;
  }

  /* L'animazione deve poter partire anche se l'observer non arriva mai
     (browser senza IntersectionObserver, iframe con visibilità strana).
     In quel caso: rivela tutto appena l'elemento è nel viewport o allo
     scroll successivo. Nessun timer che rivela elementi lontani: è proprio
     quello che neutralizzava l'animazione. */
  function fallbackReveal() {
    items.forEach(function (item) {
      if (item.el.classList.contains("is-visible")) return;
      var r = item.el.getBoundingClientRect();
      // dentro lo schermo: anima
      if (r.top < window.innerHeight && r.bottom > 0) {
        show(item);
        return;
      }
      // già oltrepassato (scroll veloce, àncora, salto di pagina): l'observer
      // può non averlo mai visto. Va mostrato subito e senza ritardo,
      // altrimenti resta invisibile sopra la piega.
      if (r.bottom <= 0) {
        item.el.style.setProperty("--reveal-delay", "0ms");
        item.el.classList.add("is-visible");
      }
    });
  }

  function show(item) {
    if (item.el.classList.contains("is-visible")) return;
    window.setTimeout(function () {
      item.el.style.setProperty("--reveal-delay", item.delay + "ms");
      item.el.classList.add("is-visible");
    }, item.delay);
  }

  /* -------------------------------------------------------- raccolta -- */
  var items = [];
  var all = Array.prototype.slice.call(document.querySelectorAll(".reveal, [data-reveal]"));

  all.forEach(function (el, index) {
    // gli elementi marcati data-reveal-stagger="none" vanno animati da soli
    var group = el.getAttribute("data-reveal-group");
    var siblings = group
      ? all.filter(function (s) { return s.getAttribute("data-reveal-group") === group; })
      : null;
    var order = siblings ? siblings.indexOf(el) : index;
    var delay = Math.min(order * STAGGER, MAX_STAGGER);
    if (el.hasAttribute("data-reveal-delay")) {
      delay = parseInt(el.getAttribute("data-reveal-delay"), 10) || 0;
    }
    items.push({ el: el, delay: delay });
  });

  /* ------------------------------------------------------------ avvio -- */
  function start() {
    // la classe js-anim può essere già stata messa dallo script inline
    // nell'head (per evitare il lampo di contenuto): va comunque rimossa
    // in tutti i casi in cui non animiamo nulla.
    if (reduced() || !("IntersectionObserver" in window)) {
      root.classList.remove("js-anim");
      root.classList.add("no-anim");
      items.forEach(function (item) { item.el.classList.add("is-visible"); });
      return;
    }

    if (!items.length) {
      root.classList.remove("js-anim");
      return;
    }

    // da qui in poi il CSS può tenere nascosto ciò che deve ancora entrare
    root.classList.add("js-anim");

    // quello che è già a schermo all'apertura entra subito, senza attesa
    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) return;
          var item = items.filter(function (i) { return i.el === entry.target; })[0];
          if (item) show(item);
          if (ONCE) observer.unobserve(entry.target);
        });
      },
      {
        // parte un filo prima di toccare il bordo: l'animazione si vede
        // mentre l'elemento sta entrando, non dopo
        rootMargin: "0px 0px -12% 0px",
        threshold: 0.01
      }
    );

    items.forEach(function (item) {
      if (inViewport(item.el)) {
        show(item);
      } else {
        observer.observe(item.el);
      }
    });

    // rete di sicurezza: se qualcosa non è mai stato osservato (layout
    // cambiato, stampa, zoom), si rivela su scroll/resize quando entra
    var pending = null;
    function onScroll() {
      if (pending) return;
      pending = window.requestAnimationFrame(function () {
        fallbackReveal();
        pending = null;
      });
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });
    // controllo iniziale differito: copre i salti da àncora (#sezione) che
    // avvengono prima che l'observer sia pronto
    window.setTimeout(fallbackReveal, 250);
  }

  /* ---------------------------------------------------------- contatori -- */
  // <span data-count="2.4" data-decimals="1" data-suffix=" Mln">0</span>
  function animateCounter(el) {
    var target = parseFloat(el.getAttribute("data-count"));
    var decimals = parseInt(el.getAttribute("data-decimals") || "0", 10);
    var prefix = el.getAttribute("data-prefix") || "";
    var suffix = el.getAttribute("data-suffix") || "";
    var duration = parseInt(el.getAttribute("data-duration") || "1500", 10);
    var startTime = null;

    function frame(ts) {
      if (startTime === null) startTime = ts;
      var p = Math.min((ts - startTime) / duration, 1);
      var eased = 1 - Math.pow(1 - p, 3);           // easeOutCubic
      var value = target * eased;
      // useGrouping: separatore migliaia italiano anche su 1.840
      el.textContent = prefix +
        Number(value).toLocaleString("it-IT", {
          minimumFractionDigits: decimals,
          maximumFractionDigits: decimals,
          useGrouping: true
        }) + suffix;
      if (p < 1) window.requestAnimationFrame(frame);
      else el.textContent = prefix + Number(target).toLocaleString("it-IT", {
        minimumFractionDigits: decimals, maximumFractionDigits: decimals,
        useGrouping: true
      }) + suffix;
    }
    window.requestAnimationFrame(frame);
  }

  function startCounters() {
    var counters = document.querySelectorAll("[data-count]");
    if (!counters.length) return;

    if (reduced() || !("IntersectionObserver" in window)) {
      counters.forEach(function (el) {
        var decimals = parseInt(el.getAttribute("data-decimals") || "0", 10);
        el.textContent = (el.getAttribute("data-prefix") || "") +
          Number(parseFloat(el.getAttribute("data-count"))).toLocaleString("it-IT", {
            minimumFractionDigits: decimals, maximumFractionDigits: decimals }) +
          (el.getAttribute("data-suffix") || "");
      });
      return;
    }

    var co = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        animateCounter(entry.target);
        co.unobserve(entry.target);
      });
    }, { threshold: 0.4 });
    counters.forEach(function (el) { co.observe(el); });
  }

  function boot() {
    start();
    startCounters();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }

  window.PatAnim = { start: start, reduced: reduced };
})();

/* ------------------------------------------------------------------
   Parallasse leggero del mockup telefono: si muove di pochi pixel
   mentre si scorre la hero. Disattivato con prefers-reduced-motion.
   ------------------------------------------------------------------ */
(function parallax(){
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce) return;
  var el = document.querySelector('.device-wrap .device') || document.querySelector('.device');
  if (!el) return;
  var ticking = false;
  function update(){
    ticking = false;
    var r = el.getBoundingClientRect();
    if (r.bottom < -200 || r.top > window.innerHeight + 200) return;
    var progress = Math.min(1, Math.max(0, (window.innerHeight - r.top) / (window.innerHeight + r.height)));
    var shift = (progress - 0.5) * 34;   /* ±17px, appena percettibile */
    el.style.transform = 'translate3d(0,' + (-shift).toFixed(2) + 'px,0)';
  }
  function onScroll(){
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(update);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onScroll);
  update();
})();
